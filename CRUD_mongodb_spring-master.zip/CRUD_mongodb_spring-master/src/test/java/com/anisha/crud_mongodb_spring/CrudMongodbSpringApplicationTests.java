package com.anisha.crud_mongodb_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudMongodbSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
